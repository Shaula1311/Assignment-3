const apiKey = 'd797e3c67ea8cb4ce216fb5665cd6e9b';
const city = 'Almaty'; 
const url = `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${apiKey}&units=metric`;

fetch(url)
.then(response => response.json())
.then(data => {
  const weatherDiv = document.getElementById('weather');
  const weatherDetails = `
    <p>City: ${data.name}</p>
    <p class="temperature">Temperature: ${data.main.temp}°C</p>
    <p class="weather-description">Weather: ${data.weather[0].main}</p>
  `;
  weatherDiv.innerHTML = weatherDetails;
})
.catch(error => console.error('Error fetching data:', error));
